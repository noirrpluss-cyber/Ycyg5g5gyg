# BLUEARENA — PUBG Tournament Platform

Sade beyaz/siyah + açık mavi arayüz. Sunucu tarafı SQLite veritabanı kullanır; kullanıcı profilleri, takımlar, turnuvalar, başvurular, check-in ve scoreboard localStorage'a yazılmaz.

## Çalıştırma

```bash
python server.py
```

Sonra `http://127.0.0.1:5050` aç.

## Admin

Admin paneli artık ayrı bir gizli giriş sayfası değildir. **Normal giriş ekranından admin hesabıyla giriş yapıldığında** kullanıcı otomatik olarak Control Room'a alınır. Admin olmayan kullanıcılar `/admin...` rotalarına sunucu tarafında 403 alır.

İlk çalıştırmada admin hesabı oluşturulur:

- kullanıcı adı: `admin`
- şifre: `ADMIN_PASSWORD` ortam değişkeni (ayar yoksa demo için `admin12345`)

Gerçek sunucuda mutlaka değiştir.

## GitHub ile giriş

GitHub ile giriş için GitHub Developer Settings → OAuth Apps → New OAuth App bölümünden bir OAuth App oluşturup `.env` değerlerini ayarla:

```text
GITHUB_CLIENT_ID=...
GITHUB_CLIENT_SECRET=...
BASE_URL=https://alan-adin.com
```

Authorized redirect URI tam olarak:

```text
https://alan-adin.com/auth/github/callback
```

Yerelde:

```text
http://127.0.0.1:5050/auth/github/callback
```

GitHub'dan gelen kullanıcı adı, doğrulanmış e-posta ve profil fotoğrafı sunucudaki SQLite hesabına bağlanır. Tarayıcı `localStorage` kullanılmaz.

## Profil fotoğrafı

Kullanıcı profilinden PNG/JPG/WEBP fotoğrafı yükleyebilir. Dosya sunucudaki `uploads/` klasöründe tutulur ve kullanıcı kaydı SQLite'ta saklanır. Maksimum 2 MB.

## Güvenlik notları

- Oturumlar HttpOnly + SameSite cookie ve sunucu tarafı session tablosu ile tutulur.
- Parolalar PBKDF2-SHA256 ile hashlenir.
- Admin API'leri sunucu tarafında role kontrolü yapar.
- GitHub OAuth callback'te state imzası ve süre kontrolü vardır.
- Kullanıcı fotoğrafı MIME + dosya imzası ile doğrulanır.
- Production'da HTTPS kullan ve `BLUEARENA_SECRET` değerini uzun/rastgele yap.
