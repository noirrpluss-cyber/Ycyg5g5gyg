#!/usr/bin/env python3
import base64, hashlib, hmac, json, os, re, secrets, sqlite3, time
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs, urlencode
from urllib.request import Request, urlopen

ROOT = os.path.dirname(os.path.abspath(__file__))

def load_dotenv(path):
    try:
        with open(path, encoding='utf-8') as f:
            for line in f:
                line=line.strip()
                if not line or line.startswith('#') or '=' not in line: continue
                k,v=line.split('=',1); k=k.strip(); v=v.strip()
                if len(v)>=2 and v[0]==v[-1] and v[0] in ('\"', "'"): v=v[1:-1]
                if k and k not in os.environ: os.environ[k]=v
    except FileNotFoundError: pass

load_dotenv(os.path.join(ROOT, '.env'))
DB_PATH = os.path.join(ROOT, 'bluearena.sqlite3')
UPLOAD_DIR = os.path.join(ROOT, 'uploads')
STATIC = os.path.join(ROOT, 'static')
try:
    PORT = int(os.environ.get('PORT') or os.environ.get('SERVER_PORT') or '5050')
except ValueError:
    PORT = 5050
SECRET = os.environ.get('BLUEARENA_SECRET', 'CHANGE-ME-BEFORE-PRODUCTION').encode()
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'admin12345')
GITHUB_CLIENT_ID = os.environ.get('GITHUB_CLIENT_ID', '')
GITHUB_CLIENT_SECRET = os.environ.get('GITHUB_CLIENT_SECRET', '')
BASE_URL = os.environ.get('BASE_URL', '').rstrip('/')
SESSION_TTL = 60 * 60 * 24 * 7
os.makedirs(UPLOAD_DIR, exist_ok=True)


def now(): return time.strftime('%Y-%m-%d %H:%M:%S')
def db():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute('PRAGMA foreign_keys=ON')
    return c

def hashpw(p):
    salt = secrets.token_bytes(16)
    dk = hashlib.pbkdf2_hmac('sha256', p.encode(), salt, 220000)
    return base64.b64encode(salt + dk).decode()

def checkpw(p, h):
    try:
        raw = base64.b64decode(h); salt, old = raw[:16], raw[16:]
        new = hashlib.pbkdf2_hmac('sha256', p.encode(), salt, 220000)
        return hmac.compare_digest(old, new)
    except Exception: return False

def slug(s): return re.sub(r'[^a-z0-9]+', '-', s.lower()).strip('-') or secrets.token_hex(4)

def init_db():
    c = db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, email TEXT UNIQUE NOT NULL,
      password_hash TEXT, role TEXT NOT NULL DEFAULT 'user', google_sub TEXT UNIQUE, github_id TEXT UNIQUE, avatar_url TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS tournaments (
      id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, slug TEXT UNIQUE NOT NULL, format TEXT NOT NULL,
      status TEXT NOT NULL, teams_max INTEGER NOT NULL, prize TEXT NOT NULL, start_at TEXT NOT NULL,
      register_until TEXT NOT NULL, checkin_until TEXT, checkin_required INTEGER NOT NULL DEFAULT 1,
      description TEXT, rules TEXT, created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS teams (
      id INTEGER PRIMARY KEY AUTOINCREMENT, team_name TEXT UNIQUE NOT NULL, captain_id INTEGER NOT NULL,
      created_at TEXT NOT NULL, FOREIGN KEY(captain_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS team_members (
      team_id INTEGER NOT NULL, user_id INTEGER NOT NULL, joined_at TEXT NOT NULL,
      PRIMARY KEY(team_id,user_id), FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT, tournament_id INTEGER NOT NULL, team_id INTEGER NOT NULL,
      status TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(tournament_id,team_id),
      FOREIGN KEY(tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE, FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS announcements (
      id INTEGER PRIMARY KEY AUTOINCREMENT, tournament_id INTEGER NOT NULL, title TEXT NOT NULL, body TEXT NOT NULL,
      created_at TEXT NOT NULL, FOREIGN KEY(tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS results (
      id INTEGER PRIMARY KEY AUTOINCREMENT, tournament_id INTEGER NOT NULL, team_id INTEGER NOT NULL,
      placement INTEGER NOT NULL, kills INTEGER NOT NULL, points INTEGER NOT NULL, match_no INTEGER NOT NULL, created_at TEXT NOT NULL,
      FOREIGN KEY(tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE, FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS checkins (
      id INTEGER PRIMARY KEY AUTOINCREMENT, tournament_id INTEGER NOT NULL, team_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL, checked_at TEXT NOT NULL, UNIQUE(tournament_id,team_id),
      FOREIGN KEY(tournament_id) REFERENCES tournaments(id) ON DELETE CASCADE, FOREIGN KEY(team_id) REFERENCES teams(id) ON DELETE CASCADE,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id INTEGER NOT NULL, expires_at INTEGER NOT NULL,
      FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
    ''')
    if not c.execute('SELECT 1 FROM users LIMIT 1').fetchone():
        c.execute('INSERT INTO users(username,email,password_hash,role,created_at) VALUES(?,?,?,?,?)', ('admin','admin@bluearena.local',hashpw(ADMIN_PASSWORD),'admin',now()))
    if not c.execute('SELECT 1 FROM tournaments LIMIT 1').fetchone():
        seeds=[('NOVA CUP — NIGHT #01','Squad',24,'2.500 ₺','2026-10-10 21:30','2026-10-10 20:45','2026-10-10 21:15','A clean night squad cup built for fast registration and clear results.'),('BLUE LEAGUE — QUALIFIER','Squad',32,'5.000 ₺','2026-10-18 20:30','2026-10-18 19:30','2026-10-18 20:15','Open qualifier. Four rounds, one clean leaderboard.'),('MIDNIGHT SCRIM #14','Scrim',16,'0 ₺','2026-10-06 23:00','2026-10-06 22:30','2026-10-06 22:45','Late-night practice lobby for registered squads.')]
        for title,fmt,mx,prize,start,reg,ci,desc in seeds:
            c.execute('INSERT INTO tournaments(title,slug,format,status,teams_max,prize,start_at,register_until,checkin_until,checkin_required,description,rules,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
                      (title,slug(title),fmt,'open',mx,prize,start,reg,ci,1,desc,'Organizatörün yayınladığı kurallar bu alanda görünür.',now()))
    c.commit(); c.close()


def migrate_json():
    old = os.path.join(ROOT, 'data.json')
    if not os.path.exists(old) or os.path.exists(DB_PATH + '.migrated'): return
    # The v2 package already contains a data.json. Import only if the SQLite DB is still empty-ish.
    try:
        with open(old, encoding='utf-8') as f: d=json.load(f)
        c=db(); count=c.execute('SELECT COUNT(*) n FROM tournaments').fetchone()['n']
        if count == 0:
            users={}
            for u in d.get('users',[]):
                c.execute('INSERT OR IGNORE INTO users(username,email,password_hash,role,created_at) VALUES(?,?,?,?,?)', (u.get('username'),u.get('email',''),u.get('password'),u.get('role','user'),now()))
                users[u.get('username')]=c.execute('SELECT id FROM users WHERE username=?',(u.get('username'),)).fetchone()['id']
            for t in d.get('tournaments',[]):
                c.execute('INSERT OR IGNORE INTO tournaments(id,title,slug,format,status,teams_max,prize,start_at,register_until,checkin_until,checkin_required,description,rules,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    (t.get('id'),t.get('title'),t.get('slug') or slug(t.get('title','cup')),t.get('format','Squad'),t.get('status','open'),t.get('teams_max',16),t.get('prize','0 ₺'),t.get('start_at',''),t.get('register_until',''),t.get('checkin_until',''),int(t.get('checkin_required',True)),t.get('description',''),t.get('rules',''),t.get('created_at',now())))
            team_map={}
            for t in d.get('teams',[]):
                cap=t.get('captain',''); uid=users.get(cap)
                if not uid: continue
                c.execute('INSERT OR IGNORE INTO teams(id,team_name,captain_id,created_at) VALUES(?,?,?,?)',(t.get('id'),t.get('team_name'),uid,now()))
                team_id=c.execute('SELECT id FROM teams WHERE team_name=?',(t.get('team_name'),)).fetchone()['id']; team_map[t.get('team_name','').lower()]=team_id
                for member in t.get('members',[]):
                    if member in users: c.execute('INSERT OR IGNORE INTO team_members(team_id,user_id,joined_at) VALUES(?,?,?)',(team_id,users[member],now()))
            for a in d.get('applications',[]):
                tid=a.get('tournament_id'); team_id=team_map.get(a.get('team_name','').lower())
                if team_id: c.execute('INSERT OR IGNORE INTO applications(id,tournament_id,team_id,status,created_at) VALUES(?,?,?,?,?)',(a.get('id'),tid,team_id,a.get('status','pending'),a.get('created_at',now())))
            c.commit()
        c.close(); open(DB_PATH+'.migrated','w').close()
    except Exception: pass

init_db(); migrate_json()
# Upgrade older V3/V4 databases without deleting existing accounts.
try:
    c=db(); cols={r['name'] for r in c.execute('PRAGMA table_info(users)')}
    if 'github_id' not in cols: c.execute('ALTER TABLE users ADD COLUMN github_id TEXT UNIQUE')
    c.commit(); c.close()
except Exception: pass


def current_user(h):
    cookie=h.headers.get('Cookie','')
    m=re.search(r'(?:^|; )sid=([^;]+)',cookie)
    if not m: return None
    c=db(); row=c.execute('SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=? AND s.expires_at>?',(m.group(1),int(time.time()))).fetchone(); c.close()
    return dict(row) if row else None

def session_cookie(h,user_id):
    token=secrets.token_urlsafe(48); c=db(); c.execute('INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,?)',(token,user_id,int(time.time())+SESSION_TTL)); c.commit(); c.close(); return token

def clear_session(h):
    m=re.search(r'(?:^|; )sid=([^;]+)',h.headers.get('Cookie',''))
    if m:
        c=db(); c.execute('DELETE FROM sessions WHERE token=?',(m.group(1),)); c.commit(); c.close()

def send_json(h,obj,status=200,extra=None):
    b=json.dumps(obj,ensure_ascii=False).encode(); h.send_response(status); h.send_header('Content-Type','application/json; charset=utf-8'); h.send_header('Content-Length',str(len(b))); h.send_header('Cache-Control','no-store'); h.send_header('X-Content-Type-Options','nosniff')
    for k,v in (extra or {}).items(): h.send_header(k,v)
    h.end_headers(); h.wfile.write(b)

def body(h):
    try: n=min(int(h.headers.get('Content-Length','0') or 0), 5_000_000); return json.loads(h.rfile.read(n) or b'{}')
    except Exception: return {}

def public_t(t):
    x=dict(t); x.pop('room_no',None); x.pop('room_password',None); return x

def github_redirect_uri(h):
    if BASE_URL:
        return BASE_URL + '/auth/github/callback'
    host = h.headers.get('Host', f'127.0.0.1:{PORT}')
    proto = h.headers.get('X-Forwarded-Proto', 'http').split(',')[0].strip()
    return f'{proto}://{host}/auth/github/callback'

def signed_state():
    payload=f'{int(time.time())}:{secrets.token_urlsafe(24)}'; sig=hmac.new(SECRET,payload.encode(),hashlib.sha256).hexdigest(); return payload+'.'+sig

def valid_state(s):
    try:
        payload,sig=s.rsplit('.',1); ts=int(payload.split(':',1)[0]); return time.time()-ts<600 and hmac.compare_digest(sig,hmac.new(SECRET,payload.encode(),hashlib.sha256).hexdigest())
    except Exception: return False

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def _file(self,path):
        if path=='/': path='/index.html'
        if path.startswith('/uploads/'):
            root=UPLOAD_DIR; rel=path[len('/uploads/'):]
        else: root=STATIC; rel=path.lstrip('/')
        p=os.path.abspath(os.path.join(root,rel))
        if not p.startswith(os.path.abspath(root)+os.sep) or not os.path.isfile(p): self.send_error(404); return
        ext=os.path.splitext(p)[1].lower(); typ={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp'}.get(ext,'application/octet-stream')
        b=open(p,'rb').read(); self.send_response(200); self.send_header('Content-Type',typ); self.send_header('Content-Length',str(len(b))); self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        path=urlparse(self.path).path; qs=parse_qs(urlparse(self.path).query); u=current_user(self)
        if path=='/auth/github':
            if not GITHUB_CLIENT_ID or not GITHUB_CLIENT_SECRET:
                send_json(self,{'error':'GitHub OAuth hazır değil. GITHUB_CLIENT_ID ve GITHUB_CLIENT_SECRET ayarla.'},503); return
            state=signed_state(); q=urlencode({'client_id':GITHUB_CLIENT_ID,'redirect_uri':github_redirect_uri(self),'scope':'read:user user:email','state':state})
            self.send_response(302); self.send_header('Location','https://github.com/login/oauth/authorize?'+q); self.send_header('Set-Cookie',f'oauth_state={state}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=600' if BASE_URL.startswith('https://') else f'oauth_state={state}; HttpOnly; SameSite=Lax; Path=/; Max-Age=600'); self.end_headers(); return
        if path=='/auth/github/callback':
            state=qs.get('state',[''])[0]; cookie=self.headers.get('Cookie',''); m=re.search(r'(?:^|; )oauth_state=([^;]+)',cookie); code=qs.get('code',[''])[0]
            if not m or not hmac.compare_digest(m.group(1),state) or not valid_state(state) or not code: self.send_error(400,'Invalid OAuth state'); return
            try:
                data=urlencode({'code':code,'client_id':GITHUB_CLIENT_ID,'client_secret':GITHUB_CLIENT_SECRET,'redirect_uri':github_redirect_uri(self)}).encode()
                tok=json.loads(urlopen(Request('https://github.com/login/oauth/access_token',data=data,headers={'Accept':'application/json','Content-Type':'application/x-www-form-urlencoded','User-Agent':'BlueArena'}),timeout=10).read())
                if not tok.get('access_token'): raise ValueError(tok.get('error_description') or 'GitHub token alınamadı.')
                hdr={'Authorization':'Bearer '+tok['access_token'],'Accept':'application/vnd.github+json','User-Agent':'BlueArena'}
                info=json.loads(urlopen(Request('https://api.github.com/user',headers=hdr),timeout=10).read())
                emails=json.loads(urlopen(Request('https://api.github.com/user/emails',headers=hdr),timeout=10).read())
                verified=[e for e in emails if e.get('verified') and e.get('primary')] or [e for e in emails if e.get('verified')]
                email=(verified[0].get('email') if verified else info.get('email'))
                if not email: raise ValueError('GitHub hesabında doğrulanmış e-posta bulunamadı.')
                github_id=str(info.get('id')); avatar=info.get('avatar_url','')
                c=db(); row=c.execute('SELECT * FROM users WHERE github_id=? OR lower(email)=lower(?)',(github_id,email)).fetchone()
                if row:
                    if not row['avatar_url']:
                        c.execute('UPDATE users SET github_id=?,avatar_url=? WHERE id=?',(github_id,avatar,row['id']))
                    else:
                        c.execute('UPDATE users SET github_id=? WHERE id=?',(github_id,row['id']))
                    uid=row['id']
                else:
                    base=re.sub(r'[^a-zA-Z0-9_]+','',info.get('login') or email.split('@')[0])[:24] or 'player'; username=base; n=2
                    while c.execute('SELECT 1 FROM users WHERE lower(username)=lower(?)',(username,)).fetchone(): username=base+str(n); n+=1
                    cur=c.execute('INSERT INTO users(username,email,password_hash,role,github_id,avatar_url,created_at) VALUES(?,?,?,?,?,?,?)',(username,email.lower(),None,'user',github_id,avatar,now())); uid=cur.lastrowid
                c.commit(); c.close(); sid=session_cookie(self,uid)
                secure='; Secure' if BASE_URL.startswith('https://') else ''
                self.send_response(302); self.send_header('Location','/#home'); self.send_header('Set-Cookie',f'sid={sid}; HttpOnly; SameSite=Lax; Path=/; Max-Age={SESSION_TTL}'+secure); self.send_header('Set-Cookie','oauth_state=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'); self.end_headers(); return
            except Exception as e:
                self.send_error(502,'GitHub giriş başarısız: '+str(e)); return
        if path.startswith('/api/'):
            if path=='/api/me': send_json(self,{'user':{k:u[k] for k in ('id','username','email','role','avatar_url')} if u else None}); return
            if path=='/api/tournaments':
                c=db(); rows=[]
                for t in c.execute('SELECT * FROM tournaments ORDER BY start_at'): 
                    x=dict(t); x['teams_count']=c.execute("SELECT COUNT(*) FROM applications WHERE tournament_id=? AND status='approved'",(t['id'],)).fetchone()[0]; rows.append(public_t(x))
                c.close(); send_json(self,rows); return
            if path=='/api/teams':
                c=db(); teams=[]
                for t in c.execute('SELECT t.*,u.username captain FROM teams t JOIN users u ON u.id=t.captain_id ORDER BY t.id DESC'):
                    members=[r['username'] for r in c.execute('SELECT u.username FROM team_members tm JOIN users u ON u.id=tm.user_id WHERE tm.team_id=? ORDER BY tm.joined_at',(t['id'],))]
                    teams.append({'id':t['id'],'team_name':t['team_name'],'captain':t['captain'],'players_count':len(members),'members':members})
                c.close(); send_json(self,teams); return
            if path=='/api/scoreboard':
                tid=int(qs.get('tournament_id',[0])[0] or 0); c=db(); sql='SELECT t.team_name,COUNT(r.id) matches,SUM(r.kills) kills,SUM(r.points) points,MIN(r.placement) best_placement FROM results r JOIN teams t ON t.id=r.team_id'; params=[]
                if tid: sql+=' WHERE r.tournament_id=?'; params.append(tid)
                sql+=' GROUP BY r.team_id ORDER BY points DESC,kills DESC,best_placement ASC,team_name ASC'; rows=[]
                for i,r in enumerate(c.execute(sql,params),1):
                    x=dict(r); x['rank']=i; rows.append(x)
                c.close(); send_json(self,rows); return
            if path=='/api/profile':
                if not u: send_json(self,{'error':'Giriş gerekli.'},401); return
                send_json(self,{'user':{k:u[k] for k in ('id','username','email','role','avatar_url')}}); return
            if path.startswith('/api/admin/'):
                if not u or u.get('role')!='admin': send_json(self,{'error':'Yetkisiz.'},403); return
                if path=='/api/admin/applications':
                    c=db(); rows=[dict(r) for r in c.execute('SELECT a.*,t.title tournament,tm.team_name,u.username captain FROM applications a JOIN tournaments t ON t.id=a.tournament_id JOIN teams tm ON tm.id=a.team_id JOIN users u ON u.id=tm.captain_id ORDER BY a.id DESC')]; c.close(); send_json(self,rows); return
                if path=='/api/admin/checkins':
                    c=db(); rows=[dict(r) for r in c.execute('SELECT c.*,t.title tournament,tm.team_name,u.username FROM checkins c JOIN tournaments t ON t.id=c.tournament_id JOIN teams tm ON tm.id=c.team_id JOIN users u ON u.id=c.user_id ORDER BY c.id DESC')]; c.close(); send_json(self,rows); return
                m=re.match(r'^/api/admin/tournament/(\d+)/teams$',path)
                if m:
                    c=db(); tid=int(m.group(1)); rows=[dict(r) for r in c.execute("SELECT tm.id,tm.team_name,u.username captain FROM applications a JOIN teams tm ON tm.id=a.team_id JOIN users u ON u.id=tm.captain_id WHERE a.tournament_id=? AND a.status='approved' ORDER BY tm.team_name",(tid,))]; c.close(); send_json(self,rows); return
                if path=='/api/admin/dashboard':
                    c=db(); stats={k:c.execute(q).fetchone()[0] for k,q in {'tournaments':'SELECT COUNT(*) FROM tournaments','applications':'SELECT COUNT(*) FROM applications','teams':'SELECT COUNT(*) FROM teams','results':'SELECT COUNT(*) FROM results','checkins':'SELECT COUNT(*) FROM checkins'}.items()}; issues=[]
                    for r in c.execute('SELECT title,start_at,register_until FROM tournaments'):
                        for key in ('start_at','register_until'):
                            if not str(r[key] or '').strip(): issues.append(f'{r["title"]}: {key} eksik.')
                    bad=c.execute("SELECT COUNT(*) FROM applications WHERE tournament_id NOT IN (SELECT id FROM tournaments) OR team_id NOT IN (SELECT id FROM teams)").fetchone()[0]
                    if bad: issues.append('Yetim başvuru kaydı bulundu.')
                    c.close(); send_json(self,{'stats':stats,'health':{'ok':not issues,'issues':issues,'api':True,'database':os.path.isfile(DB_PATH),'local_storage_used':False,'github_oauth':bool(GITHUB_CLIENT_ID and GITHUB_CLIENT_SECRET)}}); return
            m=re.match(r'^/api/tournaments/([^/]+)$',path)
            if m:
                c=db(); t=c.execute('SELECT * FROM tournaments WHERE slug=?',(m.group(1),)).fetchone()
                if not t: c.close(); send_json(self,{'error':'not_found'},404); return
                tid=t['id']; anns=[dict(x) for x in c.execute('SELECT * FROM announcements WHERE tournament_id=? ORDER BY id DESC',(tid,))]; rr=[]
                for r in c.execute('SELECT r.*,tm.team_name FROM results r JOIN teams tm ON tm.id=r.team_id WHERE r.tournament_id=? ORDER BY r.match_no,r.placement',(tid,)): rr.append(dict(r))
                checked=False
                if u: checked=bool(c.execute('SELECT 1 FROM checkins WHERE tournament_id=? AND user_id=?',(tid,u['id'])).fetchone())
                c.close(); x=dict(t); x['teams_count']=c.execute('SELECT COUNT(*) FROM applications WHERE tournament_id=? AND status="approved"',(tid,)).fetchone()[0] if False else 0
                # count separately to keep connection closed above
                c2=db(); x['teams_count']=c2.execute('SELECT COUNT(*) FROM applications WHERE tournament_id=? AND status="approved"',(tid,)).fetchone()[0]; c2.close()
                send_json(self,{'tournament':public_t(x),'announcements':anns,'results':rr,'checked_in':checked}); return
            send_json(self,{'error':'not_found'},404); return
        self._file(path)

    def do_POST(self):
        path=urlparse(self.path).path; data=body(self); u=current_user(self)
        if path=='/api/register':
            username=data.get('username','').strip(); email=data.get('email','').strip().lower(); password=data.get('password','')
            if len(username)<3 or len(password)<8 or '@' not in email: send_json(self,{'error':'Geçerli kullanıcı adı, e-posta ve 8+ karakter şifre gerekli.'},400); return
            c=db()
            if c.execute('SELECT 1 FROM users WHERE lower(username)=lower(?) OR lower(email)=lower(?)',(username,email)).fetchone(): c.close(); send_json(self,{'error':'Kullanıcı veya e-posta zaten kayıtlı.'},409); return
            c.execute('INSERT INTO users(username,email,password_hash,role,created_at) VALUES(?,?,?,?,?)',(username,email,hashpw(password),'user',now())); c.commit(); c.close(); send_json(self,{'ok':True}); return
        if path=='/api/login':
            c=db(); row=c.execute('SELECT * FROM users WHERE lower(username)=lower(?)',(data.get('username',''),)).fetchone(); c.close()
            if not row or not row['password_hash'] or not checkpw(data.get('password',''),row['password_hash']): send_json(self,{'error':'Kullanıcı adı veya şifre hatalı.'},401); return
            sid=session_cookie(self,row['id']); send_json(self,{'ok':True,'user':{'id':row['id'],'username':row['username'],'email':row['email'],'role':row['role'],'avatar_url':row['avatar_url']}},200,{'Set-Cookie':f'sid={sid}; HttpOnly; SameSite=Lax; Path=/; Max-Age={SESSION_TTL}'}) ; return
        if path=='/api/logout': clear_session(self); send_json(self,{},200,{'Set-Cookie':'sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'}); return
        if path=='/api/profile/avatar':
            if not u: send_json(self,{'error':'Giriş gerekli.'},401); return
            raw=data.get('data_url',''); m=re.match(r'^data:(image/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)$',raw)
            if not m: send_json(self,{'error':'PNG, JPG veya WEBP yükle.'},400); return
            try: blob=base64.b64decode(m.group(2),validate=True)
            except Exception: send_json(self,{'error':'Geçersiz görsel.'},400); return
            if len(blob)>2_000_000: send_json(self,{'error':'Fotoğraf en fazla 2 MB olabilir.'},400); return
            mime=m.group(1); good=(mime=='image/png' and blob.startswith(b'\x89PNG')) or (mime=='image/jpeg' and blob.startswith(b'\xff\xd8\xff')) or (mime=='image/webp' and blob.startswith(b'RIFF') and b'WEBP' in blob[:16])
            if not good: send_json(self,{'error':'Dosya türü doğrulanamadı.'},400); return
            ext={'image/png':'png','image/jpeg':'jpg','image/webp':'webp'}[mime]; name=f'user_{u["id"]}.{ext}'; open(os.path.join(UPLOAD_DIR,name),'wb').write(blob); url='/uploads/'+name
            c=db(); c.execute('UPDATE users SET avatar_url=? WHERE id=?',(url,u['id'])); c.commit(); c.close(); send_json(self,{'ok':True,'avatar_url':url}); return
        if path=='/api/team/create':
            if not u: send_json(self,{'error':'Giriş gerekli.'},401); return
            name=data.get('team_name','').strip()
            if len(name)<2: send_json(self,{'error':'Takım adı en az 2 karakter olmalı.'},400); return
            c=db()
            if c.execute('SELECT 1 FROM teams WHERE lower(team_name)=lower(?)',(name,)).fetchone(): c.close(); send_json(self,{'error':'Bu takım adı zaten kullanılıyor.'},409); return
            if c.execute('SELECT 1 FROM team_members WHERE user_id=?',(u['id'],)).fetchone(): c.close(); send_json(self,{'error':'Zaten bir takımın üyesisin.'},409); return
            cur=c.execute('INSERT INTO teams(team_name,captain_id,created_at) VALUES(?,?,?)',(name,u['id'],now())); tid=cur.lastrowid; c.execute('INSERT INTO team_members(team_id,user_id,joined_at) VALUES(?,?,?)',(tid,u['id'],now())); c.commit(); c.close(); send_json(self,{'ok':True}); return
        if path=='/api/team/join':
            if not u: send_json(self,{'error':'Giriş gerekli.'},401); return
            c=db(); t=c.execute('SELECT * FROM teams WHERE id=?',(int(data.get('team_id',0)),)).fetchone()
            if not t: c.close(); send_json(self,{'error':'Takım bulunamadı.'},404); return
            if c.execute('SELECT 1 FROM team_members WHERE team_id=? AND user_id=?',(t['id'],u['id'])).fetchone(): c.close(); send_json(self,{'ok':True,'already':True}); return
            if c.execute('SELECT 1 FROM team_members WHERE user_id=?',(u['id'],)).fetchone(): c.close(); send_json(self,{'error':'Önce mevcut takımından ayrılmalısın.'},409); return
            size=c.execute('SELECT COUNT(*) FROM team_members WHERE team_id=?',(t['id'],)).fetchone()[0]
            if size >= 4: c.close(); send_json(self,{'error':'Bu takımın oyuncu kontenjanı dolu.'},400); return
            c.execute('INSERT INTO team_members(team_id,user_id,joined_at) VALUES(?,?,?)',(t['id'],u['id'],now())); c.commit(); c.close(); send_json(self,{'ok':True}); return
        if path=='/api/apply':
            if not u: send_json(self,{'error':'Giriş gerekli.'},401); return
            tid=int(data.get('tournament_id',0)); name=data.get('team_name','').strip(); c=db(); t=c.execute('SELECT * FROM tournaments WHERE id=?',(tid,)).fetchone(); team=c.execute('SELECT * FROM teams WHERE lower(team_name)=lower(?)',(name,)).fetchone()
            if not t or t['status']!='open': c.close(); send_json(self,{'error':'Turnuva başvuruya kapalı.'},400); return
            if t['register_until'] and t['register_until'] < now(): c.close(); send_json(self,{'error':'Turnuva kayıt süresi sona erdi.'},400); return
            if not team or not c.execute('SELECT 1 FROM team_members WHERE team_id=? AND user_id=?',(team['id'],u['id'])).fetchone(): c.close(); send_json(self,{'error':'Bu takımın üyesi değilsin.'},403); return
            if int(team['captain_id']) != int(u['id']): c.close(); send_json(self,{'error':'Turnuvaya başvuruyu takım kaptanı yapmalı.'},403); return
            count=c.execute("SELECT COUNT(*) FROM applications WHERE tournament_id=? AND status='approved'",(tid,)).fetchone()[0]
            if count>=t['teams_max']: c.close(); send_json(self,{'error':'Turnuva kontenjanı dolu.'},400); return
            if c.execute('SELECT 1 FROM applications WHERE tournament_id=? AND team_id=? AND status!=?',(tid,team['id'],'rejected')).fetchone(): c.close(); send_json(self,{'error':'Bu takım zaten başvurmuş.'},409); return
            c.execute('INSERT INTO applications(tournament_id,team_id,status,created_at) VALUES(?,?,?,?)',(tid,team['id'],'pending',now())); c.commit(); c.close(); send_json(self,{'ok':True}); return
        if path=='/api/checkin':
            if not u: send_json(self,{'error':'Giriş gerekli.'},401); return
            tid=int(data.get('tournament_id',0)); name=data.get('team_name','').strip(); c=db(); t=c.execute('SELECT * FROM tournaments WHERE id=?',(tid,)).fetchone(); team=c.execute('SELECT * FROM teams WHERE lower(team_name)=lower(?)',(name,)).fetchone()
            if not t or not team or not c.execute('SELECT 1 FROM team_members WHERE team_id=? AND user_id=?',(team['id'],u['id'])).fetchone() or not c.execute("SELECT 1 FROM applications WHERE tournament_id=? AND team_id=? AND status='approved'",(tid,team['id'])).fetchone(): c.close(); send_json(self,{'error':'Bu takım için check-in yetkin yok.'},403); return
            if not t['checkin_required']: c.close(); send_json(self,{'error':'Bu turnuvada check-in kapalı.'},400); return
            deadline=t['checkin_until'] or t['start_at']
            if deadline and now() > deadline: c.close(); send_json(self,{'error':'Check-in süresi sona erdi.'},400); return
            if t['start_at'] and now() >= t['start_at']: c.close(); send_json(self,{'error':'Turnuva başladı; check-in kapandı.'},400); return
            if c.execute('SELECT 1 FROM checkins WHERE tournament_id=? AND team_id=?',(tid,team['id'])).fetchone(): c.close(); send_json(self,{'ok':True,'already':True}); return
            c.execute('INSERT INTO checkins(tournament_id,team_id,user_id,checked_at) VALUES(?,?,?,?)',(tid,team['id'],u['id'],now())); c.commit(); c.close(); send_json(self,{'ok':True}); return
        if path=='/api/admin/profile': pass
        if not u or u.get('role')!='admin': send_json(self,{'error':'Yetkisiz.'},403); return
        if path=='/api/admin/tournament':
            title=data.get('title','').strip(); c=db(); cur=c.execute('INSERT INTO tournaments(title,slug,format,status,teams_max,prize,start_at,register_until,checkin_until,checkin_required,description,rules,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',(title,slug(title)+'-'+secrets.token_hex(2),data.get('format','Squad'),'open',int(data.get('teams_max',16)),data.get('prize','0 ₺'),data.get('start_at',''),data.get('register_until',''),data.get('checkin_until',''),int(bool(data.get('checkin_required',True))),data.get('description',''),data.get('rules',''),now())); c.commit(); c.close(); send_json(self,{'ok':True}); return
        m=re.match(r'^/api/admin/tournament/(\d+)/delete$',path)
        if m:
            c=db(); c.execute('DELETE FROM tournaments WHERE id=?',(int(m.group(1)),)); c.commit(); c.close(); send_json(self,{'ok':True}); return
        m=re.match(r'^/api/admin/tournament/(\d+)/checkin-toggle$',path)
        if m:
            c=db(); t=c.execute('SELECT checkin_required FROM tournaments WHERE id=?',(int(m.group(1)),)).fetchone();
            if not t: c.close(); send_json(self,{'error':'Turnuva bulunamadı.'},404); return
            val=int(bool(data.get('enabled',not t['checkin_required']))); c.execute('UPDATE tournaments SET checkin_required=? WHERE id=?',(val,int(m.group(1)))); c.commit(); c.close(); send_json(self,{'ok':True}); return
        if path=='/api/admin/announcement':
            c=db(); c.execute('INSERT INTO announcements(tournament_id,title,body,created_at) VALUES(?,?,?,?)',(int(data['tournament_id']),data['title'],data['body'],now())); c.commit(); c.close(); send_json(self,{'ok':True}); return
        if path=='/api/admin/result':
            c=db(); tid=int(data['tournament_id']); team=c.execute('SELECT id FROM teams WHERE lower(team_name)=lower(?)',(data['team_name'],)).fetchone()
            if not team: c.close(); send_json(self,{'error':'Takım bulunamadı.'},404); return
            approved=c.execute("SELECT 1 FROM applications WHERE tournament_id=? AND team_id=? AND status='approved'",(tid,team['id'])).fetchone()
            if not approved: c.close(); send_json(self,{'error':'Bu takım seçilen turnuvada onaylı değil.'},400); return
            placement=max(1,int(data['placement'])); kills=max(0,int(data['kills'])); points=max(0,int(data['points'])); match_no=max(1,int(data['match_no']))
            c.execute('INSERT INTO results(tournament_id,team_id,placement,kills,points,match_no,created_at) VALUES(?,?,?,?,?,?,?)',(tid,team['id'],placement,kills,points,match_no,now())); c.commit(); c.close(); send_json(self,{'ok':True}); return
        m=re.match(r'^/api/admin/application/(\d+)/(approve|reject)$',path)
        if m:
            c=db(); c.execute('UPDATE applications SET status=? WHERE id=?',('approved' if m.group(2)=='approve' else 'rejected',int(m.group(1)))); c.commit(); c.close(); send_json(self,{'ok':True}); return
        send_json(self,{'error':'not_found'},404)
    def do_PUT(self): self.do_POST()

if __name__ == '__main__':
    print('=================================')
    print('       BLUEARENA SERVER')
    print('=================================')
    print(f'Bind : 0.0.0.0')
    print(f'Port : {PORT}')
    print('Server dış bağlantılara açık.')
    print('=================================')
    server = ThreadingHTTPServer(('0.0.0.0', PORT), Handler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print('Server kapatılıyor...')
    finally:
        server.server_close()
